/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projekt;

/**
 * Klasa przechowująca pozycje i średnice postaci
 * @author Maciej Trzciński
 */
public class Postac {
    /** Współrzędna x Postaci */
   public static int srodek_x=505;
    /** Współrzędna y Postaci */
   public static int srodek_y=315;
    /** Średnica Postaci */
   public static int srednica_ciala=100;

    
}

